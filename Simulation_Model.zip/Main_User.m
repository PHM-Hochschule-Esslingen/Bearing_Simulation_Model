clear all;
close all;
clc;


%% User main (modifications only required here)
saveSignal = 0; % =1 if the results are to be saved, =0 if not (When saving, a folder is automatically created in the current path in which the results are saved)

nameParameterList = "Simulation_Parameters.xlsx";

nameFolderResults = "Results"; % name of the folder created with the saved results


%% Main setup simulation (no change here!)
Main_Setup_Simulation
